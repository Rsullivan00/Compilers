int x(int y, int z){
   &1 = *y;
}