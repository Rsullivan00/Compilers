int a, b, c;

int foo(void) {

    a = 1;
    b = 1 - 2;
    c = a - b; 
}
