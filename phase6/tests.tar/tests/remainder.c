int a, b, c;

int foo(void) {
    a = 4;
    b = a % 3;
    c = a % b; 
}
