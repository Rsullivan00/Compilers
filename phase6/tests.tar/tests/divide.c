int a, b, c;

int foo(void) {

    a = 2;
    b = a / 2;
    c = b / a; 
}
