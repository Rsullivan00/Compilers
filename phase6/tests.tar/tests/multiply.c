int a, b, c;

int foo(void) {

    a = 2;
    b = a * 3;
    c = a * b; 
}
