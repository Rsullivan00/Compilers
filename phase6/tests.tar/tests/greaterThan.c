int a, b, c;

void foo(void) {
    a = 0 > 1;
    b = 1 > 0;
    c = b > a; 
}
