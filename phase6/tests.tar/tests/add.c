int a, b, c;

void foo(void) {

    a = 1;
    b = a + 1;
    c = a + b; 
}
