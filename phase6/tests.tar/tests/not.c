int a, b, c;

void foo(void) {
    a = 0;
    b = !a;
    c = !!!b;
}
