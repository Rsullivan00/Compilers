int a, b, c;

void foo(void) {
    a = 1;
    b = -a;
    c = -(-(-b)); 
}
