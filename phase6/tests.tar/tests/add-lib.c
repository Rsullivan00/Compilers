/*
 * This file will not be run through your compiler.
 */

extern int a, b, c;

int main(void)
{
    foo();
    printf("%d\n", a);
    printf("%d\n", b);
    printf("%d\n", c);
}
