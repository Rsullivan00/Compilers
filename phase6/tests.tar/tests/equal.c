int a, b, c;

void foo(void) {
    a = 0 == 1;
    b = 3 == 3;
    c = b == a; 
}
