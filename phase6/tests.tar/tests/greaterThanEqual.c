int a, b, c, d;

void foo(void) {
    a = 0 >= 1;
    b = 1 >= 0;
    d = 1;
    c = b >= d; 
}
