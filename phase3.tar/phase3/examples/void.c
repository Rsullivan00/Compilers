/* void.c */

void f(void)
{
}

void x;				/* 'x' has void type */
void g(void y);			/* 'y' has void type */
void *h(void);
