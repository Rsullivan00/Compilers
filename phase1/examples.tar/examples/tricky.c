/* tricky.c */

/***
 *** a tricky comment ******/

int main(void)
{
    int a, b, c;

    a = 0123;
    b = 123;
    c = 0x123aF;

    printf("I said \"hello there\"");
}
